from .exceptions import NotFittedError
from .exceptions import ZeroObservationsError

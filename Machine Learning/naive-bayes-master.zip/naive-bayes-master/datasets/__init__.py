from .datasets import load_loan_defaulters
from .datasets import load_pima_indians

from .statistics import gaussian_pdf
from .statistics import mean
from .statistics import variance

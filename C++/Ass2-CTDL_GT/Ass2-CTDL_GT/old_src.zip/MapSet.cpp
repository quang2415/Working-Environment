#include "MapSet.h"

#define COUNTY 10  

MapSet::MapSet()
{
	root = NULL;
	count = 0;
}


MapSet::~MapSet()
{
	clear();
}

void MapSet::clearRec(AVLNode* root) {
	if (root != NULL) {
		clearRec(root->left);
		clearRec(root->right);
		delete root;
	}
}
void MapSet::clear() {
	clearRec(root);
	root = NULL;
	count = 0;
}
void MapSet::printInOrderRecursion(AVLNode* root) {
	if (root != NULL) {		
		printInOrderRecursion(root->left);
		cout << setw(20) << left << root->word.c_str() << "|" << setw(10) << right << root->freq << "|";
		root->list.print();
		cout << endl;
		printInOrderRecursion(root->right);
	}
}

void MapSet::print() {
	cout << "The total number of words: " << count << endl;
	cout << "---------------------------------------" << endl;
	cout << setw(20) << left << "Word" << "|" << setw(10) << right << "Freq." << "|" << "Line No." << endl;
	cout << "---------------------------------------" << endl;
	printInOrderRecursion(root);
	cout << "---------------------------------------" << endl;
}

//void left_rotate(AVLNode* node) {
//	AVLNode *y = node->right;
//	AVLNode *T2 = y->left;
//
//	// Perform rotation  
//	y->left = node;
//	node->right = T2;
//}
//
//void right_rotate(AVLNode* node) {
//	AVLNode *x = node->left;
//	AVLNode *T2 = x->right;
//
//	// Perform rotation  
//	x->right = node;
//	node->left = T2;
//}

AVLNode* MapSet::right_rotate(AVLNode* parent) {//left-left case
	AVLNode* x = parent->left;
	AVLNode* y = x->right;
	x->right = parent;
	parent->left = y;
	/*cout << "parent : " << parent->word << endl;
	cout << "x : " << x->word << endl;
	cout << "y : " << y->word << endl;*/
	//parent = 10; x = 5; y = 8
	parent->balance = 0;
	x->balance = 0;
	return x;
}

AVLNode* MapSet::left_rotate(AVLNode* parent) {//right-right case	
	AVLNode* x = parent->right;
	AVLNode* y = x->left;
	x->left = parent;
	parent->right = y;
	/*cout << "parent : " << parent->word << endl;
	cout << "x : " << x->word << endl;
	cout << "y : " << y->word << endl;*/
	parent->balance = 0;
	x->balance = 0;
	return x;
}

//void lr_rotate(AVLNode* parent) {
//	rr_rotate(parent->left);
//	ll_rotate(parent);
//	parent->balance = -1;
//	parent->left->right->balance = 0;
//	parent->left->balance = 0;
//	parent->left->left->balance = -1;
//}
//
//void rl_rotate(AVLNode* parent) {
//	ll_rotate(parent->right);
//	rr_rotate(parent);
//	parent->balance = 1;
//	
//}

void print2DUtil(AVLNode* root, int space)
{
	if (root == NULL)
		return;
 
	space += COUNTY;

	print2DUtil(root->right, space);

	cout << endl;
	for (int i = COUNTY; i < space; i++)
		cout << " ";
	cout << root->word << "\n";

	print2DUtil(root->left, space);
}

void MapSet::print2D(AVLNode* root)
{
	print2DUtil(root, 0);
}

void MapSet::add(string word, int line) {
	if (root == NULL) {
		root = new AVLNode(word, line);
		count++;
		return;
	}
	AVLNode* temp = root;
	AVLNode* rotate = NULL;
	while (temp) {
		if (word < temp->word) {
			if (temp->balance == -1) {
				rotate = temp;
				temp = temp->left;
				continue;
			}
			if (temp->left == NULL) {
				temp->left = new AVLNode(word, line);
				temp->balance -= 1;
				count++;
				break;
			}
			temp->balance -= 1;
			temp = temp->left;
		}
		else if (word > temp->word) {
			if (temp->balance == 1) {
				rotate = temp;
				temp = temp->right;
				continue;
			}
			
			if (temp->right==NULL) {
				temp->right = new AVLNode(word, line);
				temp->balance += 1;
				count++;
				break;
			}
			temp->balance += 1;
			temp = temp->right;
			
		}
		else {
			temp->freq++;
			temp->list.add(line);
			return;
		}

		/*if (temp == NULL) {
			temp = new AVLNode(word, line);
			count++;
		}*/
		
	}
	//if (rotate != NULL) {
	//	if (rotate->balance < 0) {
	//		if (rotate->left->balance < 0) {//left left
	//			rotate = right_rotate(rotate);
	//		}
	//		else {//left right
	//			rotate->left = left_rotate(rotate->left);
	//			rotate = right_rotate(rotate);
	//		}
	//	}
	//	else {
	//		if (rotate->right->balance > 0) {//right right
	//			rotate = left_rotate(rotate);
	//		}
	//		else {//right left
	//			rotate->right = right_rotate(rotate->right);
	//			rotate = left_rotate(rotate);
	//		}
	//	}
	//}
	
}
